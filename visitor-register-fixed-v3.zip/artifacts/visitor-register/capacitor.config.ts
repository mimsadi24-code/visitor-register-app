import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.mimsadi.visitorregister',
  appName: 'Visitor Register',
  webDir: 'dist/public',
};

export default config;
